package registration;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    @Before
    public void resetData() {
        // Clear static lists before each test
        Message.sentMessages.clear();
    }

  
    // 1. Test populateSentMessages()
  
    @Test
    public void testPopulateSentMessages() {
        Message m1 = new Message("+27111111111", "Hello world message example.");
        Message m2 = new Message("+27222222222", "Second message content.");

        Message.sentMessages.add(m1);
        Message.sentMessages.add(m2);

        String[] expected = {
            m1.getContent(),
            m2.getContent()
        };

        assertArrayEquals(expected, Message.populateSentMessages());
    }

    
    // 2. Test displayLongestMessage()
  
    @Test
    public void testDisplayLongestMessage() {
        Message m1 = new Message("+27123456789", "Short message.");
        Message m2 = new Message("+27123456789", "This is a much longer message for testing.");

        Message.sentMessages.add(m1);
        Message.sentMessages.add(m2);

        
    }

 
    // 3. Test searchMessageID() (using index)
    
    @Test
    public void testSearchMessageID() {
        Message m1 = new Message("+27111111111", "Msg 1");
        Message m2 = new Message("+27222222222", "Msg 2");
        Message m3 = new Message("+27333333333", "Msg 3");

        Message.sentMessages.add(m1);
        Message.sentMessages.add(m2);
        Message.sentMessages.add(m3);

        // searchMessageID("2") should return recipient of 2nd messa
    }

    
    // 4. Test unique Message IDs
   
    @Test
    public void testUniqueMessageIDs() {
        Message m1 = new Message("+27111111111", "First test message.");
        Message m2 = new Message("+27222222222", "Second test message.");

        assertNotEquals(m1.getMessageID(), m2.getMessageID());
    }

    
    // 5. Test hash format
 
    @Test
    public void testHashFormat() {
        Message m = new Message("+27123456789", "Hello world test.");

        String hash = m.getHash();

        // Example: 12:1:HELLOTEST.
        assertTrue(hash.contains(":"));
        assertTrue(hash.length() > 5);
    }
}