package registration;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    //  checkUserName() Tests 
    @Test
    public void testValidUserName() {
        assertTrue(Login.checkUserName("kyl_1"));
    }

    @Test
    public void testInvalidUserName_TooLong() {
        assertFalse(Login.checkUserName("kyle_123"));
    }

    @Test
    public void testInvalidUserName_NoUnderscore() {
        assertFalse(Login.checkUserName("kyle1"));
    }

    //  checkPasswordComplexity() Tests 
    @Test
    public void testValidPassword() {
        assertTrue(Login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testInvalidPassword_TooShort() {
        assertFalse(Login.checkPasswordComplexity("Ch&9!"));
    }

    @Test
    public void testInvalidPassword_NoUppercase() {
        assertFalse(Login.checkPasswordComplexity("ch&&sec@ke99!"));
    }

    @Test
    public void testInvalidPassword_NoDigit() {
        assertFalse(Login.checkPasswordComplexity("Ch&&sec@ke!!"));
    }

    @Test
    public void testInvalidPassword_NoSpecialChar() {
        assertFalse(Login.checkPasswordComplexity("Chsecake99"));
    }

    //  checkCellPhoneNumber() Tests 
    @Test
    public void testValidPhoneNumber() {
        assertTrue(Login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testInvalidPhoneNumber_NoPlus() {
        assertFalse(Login.checkCellPhoneNumber("27838968976"));
    }

    @Test
    public void testInvalidPhoneNumber_WrongLength() {
        assertFalse(Login.checkCellPhoneNumber("+278389"));
    }

    //  registerUser() Tests 
    @Test
    public void testRegisterUserSuccess() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
                "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.",
                result);
    }

    @Test
    public void testRegisterUserInvalidUsername() {
        Login login = new Login();
        String result = login.registerUser("kyle123", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
                "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.",
                result);
    }

    @Test
    public void testRegisterUserInvalidPassword() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "password", "+27838968976");
        assertEquals(
                "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                result);
    }

    @Test
    public void testRegisterUserInvalidPhoneNumber() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "0838968976");
        assertEquals(
                "Cell phone number incorrectly formatted or does not contain international code.",
                result);
    }

    //  loginUser() Tests 
    @Test
    public void testLoginSuccess() {
        Registration.setUserName("kyl_1");
        Registration.setPassword("Ch&&sec@ke99!");
        Login login = new Login();
        login.setEnteredUsername("kyl_1");
        login.setEnteredPassword("Ch&&sec@ke99!");
        assertTrue(login.loginUser());
    }

    @Test
    public void testLoginFailure_WrongUsername() {
        Registration.setUserName("kyl_1");
        Registration.setPassword("Ch&&sec@ke99!");
        Login login = new Login();
        login.setEnteredUsername("wrong");
        login.setEnteredPassword("Ch&&sec@ke99!");
        assertFalse(login.loginUser());
    }

    @Test
    public void testLoginFailure_WrongPassword() {
        Registration.setUserName("kyl_1");
        Registration.setPassword("Ch&&sec@ke99!");
        Login login = new Login();
        login.setEnteredUsername("kyl_1");
        login.setEnteredPassword("wrongpass");
        assertFalse(login.loginUser());
    }
}
