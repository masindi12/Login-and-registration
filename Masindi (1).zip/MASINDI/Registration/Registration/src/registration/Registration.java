package registration;

import javax.swing.JOptionPane;

public class Registration {
    private static String firstName;
    private static String lastName;
    private static String password;
    private static String username;
    private static String phoneNumber;

    // Getters and Setters
    public static void setFirstName(String name) { firstName = name; }
    public static String getFirstName() { return firstName; }

    public static void setLastName(String surname) { lastName = surname; }
    public static String getLastName() { return lastName; }

    public static void setUserName(String userName) { username = userName; }
    public static String getUserName() { return username; }

    public static void setPassword(String pass) { password = pass; }
    public static String getPassword() { return password; }

    public static void setPhoneNumber(String phone) { phoneNumber = phone; }
    public static String getPhoneNumber() { return phoneNumber; }

    // Main application
    public static void main(String[] args) {
        registerUserFlow();
        loginFlow();
    }

    // Registration Flow
    private static void registerUserFlow() {
        String fName = JOptionPane.showInputDialog("Enter your first name:");
        if (fName == null) System.exit(0);
        setFirstName(fName);

        String lName = JOptionPane.showInputDialog("Enter your last name:");
        if (lName == null) System.exit(0);
        setLastName(lName);

        String user;
        while (true) {
            user = JOptionPane.showInputDialog("Enter username (≤5 chars, must contain '_'):");
            if (user == null) System.exit(0);
            if (Login.checkUserName(user)) break;
            JOptionPane.showMessageDialog(null, "Invalid username format.");
        }
        setUserName(user);

        String pass;
        while (true) {
            pass = JOptionPane.showInputDialog("Enter password (≥8 chars, 1 uppercase, 1 number, 1 special):");
            if (pass == null) System.exit(0);
            if (Login.checkPasswordComplexity(pass)) break;
            JOptionPane.showMessageDialog(null, "Password does not meet complexity requirements.");
        }
        setPassword(pass);

        String phone;
        while (true) {
            phone = JOptionPane.showInputDialog("Enter phone number (+27XXXXXXXXX):");
            if (phone == null) System.exit(0);
            if (Login.checkCellPhoneNumber(phone)) break;
            JOptionPane.showMessageDialog(null, "Phone number invalid or missing international code.");
        }
        setPhoneNumber(phone);

        Login login = new Login();
        JOptionPane.showMessageDialog(null, login.registerUser(getUserName(), getPassword(), getPhoneNumber()));

        postRegistrationOptions();
    }

    // Post-Registration Options
    private static void postRegistrationOptions() {
        Object[] options = {"Login", "Register Another User", "Exit"};
        while (true) {
            int choice = JOptionPane.showOptionDialog(null,
                    "Select an option:",
                    "QuickChat",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            if (choice == 0) {
                loginFlow();
                break;
            } else if (choice == 1) {
                registerUserFlow();
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Goodbye!");
                System.exit(0);
            }
        }
    }

    // Login Flow
    private static void loginFlow() {
        Login login = new Login();
        int attempts = 0;
        final int MAX_ATTEMPTS = 3;

        while (attempts < MAX_ATTEMPTS) {
            String enteredUser = JOptionPane.showInputDialog("Enter username to login:");
            if (enteredUser == null) System.exit(0);
            String enteredPass = JOptionPane.showInputDialog("Enter password to login:");
            if (enteredPass == null) System.exit(0);

            login.setEnteredUsername(enteredUser);
            login.setEnteredPassword(enteredPass);

            if (login.loginUser()) {
                JOptionPane.showMessageDialog(null, login.returnLoginStatus());
                messagingOptions();
                return;
            } else {
                attempts++;
                JOptionPane.showMessageDialog(null,
                        "Login failed (" + attempts + "/" + MAX_ATTEMPTS + ")");
            }
        }

        JOptionPane.showMessageDialog(null, "Maximum login attempts exceeded.");
        System.exit(0);
    }

    // Enhanced Messaging Menu with all features
    private static void messagingOptions() {
        while (true) {
            String option = JOptionPane.showInputDialog(
                    "MENU:\n" +
                    "1. Send Message\n" +
                    "2. Show Sent Messages (Sender & Recipient)\n" +
                    "3. Show Longest Sent Message\n" +
                    "4. Search Message by ID\n" +
                    "5. Search Messages by Recipient\n" +
                    "6. Delete Message by Hash\n" +
                    "7. Full Sent Message Report\n" +
                    "8. Quit\n" +
                    "Enter option:");

            if (option == null) {
                JOptionPane.showMessageDialog(null, "Goodbye!");
                System.exit(0);
            }

            switch (option) {
                case "1":
                    Message.startMessaging();
                    break;
                case "2":
                    Message.showSenderAndRecipient();
                    break;
                case "3":
                    Message.showLongestMessage();
                    break;
                case "4":
                    Message.searchByMessageID();
                    break;
                case "5":
                    Message.searchByRecipient();
                    break;
                case "6":
                    Message.deleteByHash();
                    break;
                case "7":
                    Message.fullReport();
                    break;
                case "8":
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }
}