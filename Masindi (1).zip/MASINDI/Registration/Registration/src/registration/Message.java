package registration;

import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {

    static Object[] populateSentMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private String messageID;
    private String recipient;
    private String content;
    private String hash;
    
    // Stores all messages by category
    static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    
    private static int totalMessages = 0;

    public Message(String recipient, String content) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.content = content;
        this.hash = generateHash();
    }

    // Getters
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getHash() { return hash; }

    // IMPROVED MESSAGE ID METHOD (PREVENTS DUPLICATES)
    private String generateMessageID() {
        Random rand = new Random();
        String id;

        while (true) {
            id = String.valueOf(100000000 + rand.nextInt(900000000));  // 9-digit ID

            boolean exists = false;
            for (Message msg : sentMessages) {
                if (msg.messageID.equals(id)) {
                    exists = true;
                    break;
                }
            }

            if (!exists) break;  // ID is unique → exit loop
        }

        return id;
    }

    private String generateHash() {
        totalMessages++;
        String[] words = content.trim().split("\\s+");
        String first = words.length > 0 ? words[0].toUpperCase() : "EMPTY";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        return messageID.substring(0, 2) + ":" + totalMessages + ":" + first + last;
    }

    public String displayMessage() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + hash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + content;
    }

    // DISPLAY MESSAGE HISTORY
    public static String displayMessageHistory() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }

        StringBuilder history = new StringBuilder();
        history.append("===== MESSAGE HISTORY =====\n\n");

        for (Message msg : sentMessages) {
            history.append(msg.displayMessage()).append("\n\n");
        }

        return history.toString();
    }

    public static void startMessaging() {
        String previousRecipient = null;
        int totalSent = 0;

        String countStr = JOptionPane.showInputDialog("How many messages would you like to send?");
        if (countStr == null) return;

        int numMessages;
        try {
            numMessages = Integer.parseInt(countStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid number.");
            return;
        }

        for (int i = 1; i <= numMessages; i++) {
            String recipient;
            while (true) {
                recipient = JOptionPane.showInputDialog(
                        previousRecipient != null ?
                        "Enter recipient or press Enter to use previous (" + previousRecipient + "):" :
                        "Enter recipient (start with '+', max 13 chars):");
                
                if (recipient == null) return;
                if (recipient.isEmpty() && previousRecipient != null) {
                    recipient = previousRecipient;
                    break;
                }
                
                if (recipient.startsWith("+") && recipient.length() <= 13) break;
                JOptionPane.showMessageDialog(null, "Invalid recipient format.");
            }

            previousRecipient = recipient;

            String content;
            while (true) {
                content = JOptionPane.showInputDialog("Enter message content (max 250 chars):");
                if (content == null) return;
                if (content.length() <= 250) break;
                JOptionPane.showMessageDialog(null, "Message too long. Maximum 250 characters.");
            }

            Object[] options = {"Send", "Discard", "Store"};
            int action = JOptionPane.showOptionDialog(null,
                    "Choose an action for the message:",
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            Message msg = new Message(recipient, content);
            
            if (action == 0) { 
                sentMessages.add(msg);
                saveMessageToJSON(recipient,content);//save to JSON
                totalSent++;
                JOptionPane.showMessageDialog(null, "Message Sent!\n\n" + msg.displayMessage());

            } else if (action == 1) {
                disregardedMessages.add(msg);
                JOptionPane.showMessageDialog(null, "Message discarded.");

            } else if (action == 2) {
                storedMessages.add(msg);
                saveMessageToJSON(recipient,content);//save to JSON
                JOptionPane.showMessageDialog(null, "Message stored for later.");
                
            } else {
                JOptionPane.showMessageDialog(null, "Action cancelled.");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalSent);
    }

    // messaging features
    public static void showSenderAndRecipient() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }
        
        StringBuilder sb = new StringBuilder("Sender and Recipient List:\n");
        for (Message msg : sentMessages) {
            sb.append("Sender: ").append(Registration.getPhoneNumber())
              .append(" → Recipient: ").append(msg.getRecipient()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void showLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }
        
        String longest = "";
        for (Message msg : sentMessages) {
            if (msg.getContent().length() > longest.length()) {
                longest = msg.getContent();
            }
        }
                
        JOptionPane.showMessageDialog(null, "Longest message: " + longest);
    }

    public static void searchByMessageID() {
        String id = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (id == null) return;
        
        for (Message msg : sentMessages) {
            if (msg.getMessageID().equals(id)) {
                JOptionPane.showMessageDialog(null, 
                    "Recipient: " + msg.getRecipient() + 
                    "\nMessage: " + msg.getContent());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    public static void searchByRecipient() {
        String recipient = JOptionPane.showInputDialog("Enter recipient number to search:");
        if (recipient == null) return;
        
        StringBuilder sb = new StringBuilder("Messages sent to " + recipient + ":\n");
        for (Message msg : sentMessages) {
            if (msg.getRecipient().equals(recipient)) {
                sb.append(msg.getContent()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void deleteByHash() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        if (hash == null) return;
        
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).getHash().equals(hash)) {
                sentMessages.remove(i);
                JOptionPane.showMessageDialog(null, "Message deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Hash not found.");
    }

    public static void fullReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }
        
        StringBuilder sb = new StringBuilder("Full Sent Message Report:\n");
        for (Message msg : sentMessages) {
            sb.append("Hash: ").append(msg.getHash()).append("\n")
              .append("Recipient: ").append(msg.getRecipient()).append("\n")
              .append("Message: ").append(msg.getContent()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // JSON saving method 
    private static void saveMessageToJSON(String recipient, String content) {
        String json = "{ \"recipient\": \"" + recipient + "\", \"message\": \"" + content + "\" }";
        try (FileWriter file = new FileWriter("saved_messages.json", true)) {
            file.write(json + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message to file: " + e.getMessage());
        }
        
    }
}